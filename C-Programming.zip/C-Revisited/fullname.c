#include <stdio.h>
#include <string.h>

char first[100];        /* first name of person we are working with */
char last[100];         /* His last name */
char fullname[200];

int main() {
    printf("Enter first name: ");
    fgets(first, sizeof(first), stdin);
    /*first[strlen(first)-1]='\0';*/

    printf("Enter last name: ");
    fgets(last, sizeof(last), stdin);
    /*last[strlen(last)-1]='\0';*/

    strcpy(fullname, first);
    strcat(fullname, " ");
    strcat(fullname, last);

    printf("The name is %s\n", fullname);
    return (0);
}
