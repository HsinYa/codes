/************************************************************************ 
 *
 * Purpose: Part two of a two part example showing the 
 *          extern keyword in action.
 *
 * Author:  M. J. Leslie
 *
 * Date:    24-Oct-95
 *
 ************************************************************************/
static int count=5;
main()
{
  write_extern();
}

  
