/************************************************************************ 
 *
 * Purpose: Part one of a two part example showing the 
 *          extern keyword in action.
 *
 * Author:  M. J. Leslie
 *
 * Date:    24-Oct-95
 *
 ************************************************************************/
#include<stdio.h>

void write_extern(void);


void write_extern(void)
{ 
  printf("count is %d\n", count);

}

  
