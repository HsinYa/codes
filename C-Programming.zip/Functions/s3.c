/************************************************************************ 
 *
 * Purpose: Part two of a two part example showing the 
 *          extern keyword in action.
 *
 * Author:  M. J. Leslie
 *
 * Date:    24-Oct-95
 *
 ************************************************************************/
#include<stdio.h>
void test(){
    int i=0;
    for (i=0; i<2; i++){
        static int t=1;
        printf("t=%d\n",t);
        t++;
    }
}
main()
{
    int i=0;
    for (i=0; i<3; i++){
        test();
    }
}

  
